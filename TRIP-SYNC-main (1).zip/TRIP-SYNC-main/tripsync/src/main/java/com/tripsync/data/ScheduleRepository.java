package com.tripsync.data;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import com.tripsync.model.Category;
import com.tripsync.model.ScheduleItem;

public final class ScheduleRepository {

    private ScheduleRepository() {
    }

    public static List<ScheduleItem> findAllByTrip(long tripId) {
        String sql = """
                SELECT schedule_id, trip_id, schedule_date, schedule_time, place_name, category, memo, updated_at
                FROM schedule_item
                WHERE trip_id = ?
                ORDER BY schedule_date, schedule_time
                """;

        List<ScheduleItem> items = new ArrayList<>();

        try (PreparedStatement ps = Database.connection().prepareStatement(sql)) {
            ps.setLong(1, tripId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    items.add(mapRow(rs));
                }
            }
            return items;
        } catch (SQLException e) {
            throw new DataAccessException("일정 목록을 불러오지 못했습니다.", e);
        }
    }

    public static Set<LocalDate> findDatesByTrip(long tripId) {
        String sql = "SELECT DISTINCT schedule_date FROM schedule_item WHERE trip_id = ?";
        Set<LocalDate> dates = new HashSet<>();

        try (PreparedStatement ps = Database.connection().prepareStatement(sql)) {
            ps.setLong(1, tripId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    dates.add(LocalDate.parse(rs.getString("schedule_date")));
                }
            }
            return dates;
        } catch (SQLException e) {
            throw new DataAccessException("일정 날짜 목록을 불러오지 못했습니다.", e);
        }
    }

    public static Optional<ScheduleItem> findById(long scheduleId) {
        String sql = """
                SELECT schedule_id, trip_id, schedule_date, schedule_time, place_name, category, memo, updated_at
                FROM schedule_item
                WHERE schedule_id = ?
                """;

        try (PreparedStatement ps = Database.connection().prepareStatement(sql)) {
            ps.setLong(1, scheduleId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new DataAccessException("일정 항목을 불러오지 못했습니다.", e);
        }
    }

    public static ScheduleItem create(long tripId, LocalDate date, LocalTime time, String placeName, Category category, String memo) {
        String sql = """
                INSERT INTO schedule_item (trip_id, schedule_date, schedule_time, place_name, category, memo, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """;
        LocalDateTime now = LocalDateTime.now();

        try (PreparedStatement ps = Database.connection()
                .prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setLong(1, tripId);
            ps.setString(2, date != null ? date.toString() : null);
            ps.setString(3, time != null ? time.toString() : null);
            ps.setString(4, placeName);
            ps.setString(5, category != null ? category.name() : null);
            ps.setString(6, memo);
            ps.setString(7, now.toString());
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (!keys.next()) {
                    throw new DataAccessException("일정 번호를 발급받지 못했습니다.");
                }
                return new ScheduleItem(keys.getLong(1), tripId, date, time, placeName, category, memo);
            }
        } catch (SQLException e) {
            throw new DataAccessException("일정 항목을 저장하지 못했습니다.", e);
        }
    }

    public static void update(long scheduleId, long tripId, LocalDate date, LocalTime time, String placeName, Category category, String memo) {
        String sql = """
                UPDATE schedule_item
                SET schedule_date = ?, schedule_time = ?, place_name = ?, category = ?, memo = ?, updated_at = ?
                WHERE schedule_id = ?
                """;

        try (PreparedStatement ps = Database.connection().prepareStatement(sql)) {
            ps.setString(1, date != null ? date.toString() : null);
            ps.setString(2, time != null ? time.toString() : null);
            ps.setString(3, placeName);
            ps.setString(4, category != null ? category.name() : null);
            ps.setString(5, memo);
            ps.setString(6, LocalDateTime.now().toString());
            ps.setLong(7, scheduleId);

            if (ps.executeUpdate() == 0) {
                throw new DataAccessException("수정할 일정 항목을 찾지 못했습니다.");
            }
        } catch (SQLException e) {
            throw new DataAccessException("일정 항목을 수정하지 못했습니다.", e);
        }
    }

    public static void delete(long scheduleId) {
        String sql = "DELETE FROM schedule_item WHERE schedule_id = ?";

        try (PreparedStatement ps = Database.connection().prepareStatement(sql)) {
            ps.setLong(1, scheduleId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("일정 항목을 삭제하지 못했습니다.", e);
        }
    }

    private static ScheduleItem mapRow(ResultSet rs) throws SQLException {
        String dateStr = rs.getString("schedule_date");
        String timeStr = rs.getString("schedule_time");
        String catStr = rs.getString("category");

        return new ScheduleItem(
                rs.getLong("schedule_id"),
                rs.getLong("trip_id"),
                dateStr != null ? LocalDate.parse(dateStr) : null,
                timeStr != null ? LocalTime.parse(timeStr) : null,
                rs.getString("place_name"),
                catStr != null ? Category.valueOf(catStr) : null,
                rs.getString("memo")
        );
    }
}