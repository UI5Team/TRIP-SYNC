package com.tripsync.data;

public final class SessionStore {

    private SessionStore() {
    }

    public static void clear() {
    }
}