package com.tripsync.data;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.tripsync.model.Category;
import com.tripsync.model.WishlistItem;

public final class WishlistRepository {

    private WishlistRepository() {
    }

    public static List<WishlistItem> findAllByTrip(long tripId) {
        String sql = """
                SELECT wishlist_id, trip_id, place_name, category, note, completed, updated_at
                FROM wishlist_item
                WHERE trip_id = ?
                ORDER BY wishlist_id DESC
                """;

        List<WishlistItem> items = new ArrayList<>();

        try (PreparedStatement ps = Database.connection().prepareStatement(sql)) {
            ps.setLong(1, tripId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    items.add(mapRow(rs));
                }
            }
            return items;
        } catch (SQLException e) {
            throw new DataAccessException("위시리스트 목록을 불러오지 못했습니다.", e);
        }
    }

    public static Optional<WishlistItem> findById(long wishlistId) {
        String sql = """
                SELECT wishlist_id, trip_id, place_name, category, note, completed, updated_at
                FROM wishlist_item
                WHERE wishlist_id = ?
                """;

        try (PreparedStatement ps = Database.connection().prepareStatement(sql)) {
            ps.setLong(1, wishlistId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new DataAccessException("위시리스트 항목을 불러오지 못했습니다.", e);
        }
    }

    public static WishlistItem create(long tripId, String placeName, Category category, String note) {
        String sql = """
                INSERT INTO wishlist_item (trip_id, place_name, category, note, completed, updated_at)
                VALUES (?, ?, ?, ?, 0, ?)
                """;
        LocalDateTime now = LocalDateTime.now();

        try (PreparedStatement ps = Database.connection()
                .prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setLong(1, tripId);
            ps.setString(2, placeName);
            ps.setString(3, category.name());
            ps.setString(4, note);
            ps.setString(5, now.toString());
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (!keys.next()) {
                    throw new DataAccessException("위시리스트 번호를 발급받지 못했습니다.");
                }
                return new WishlistItem(keys.getLong(1), tripId, placeName, category, note, false);
            }
        } catch (SQLException e) {
            throw new DataAccessException("위시리스트 항목을 저장하지 못했습니다.", e);
        }
    }

    public static void update(long wishlistId, String placeName, Category category, String note) {
        String sql = """
                UPDATE wishlist_item
                SET place_name = ?, category = ?, note = ?, updated_at = ?
                WHERE wishlist_id = ?
                """;

        try (PreparedStatement ps = Database.connection().prepareStatement(sql)) {
            ps.setString(1, placeName);
            ps.setString(2, category.name());
            ps.setString(3, note);
            ps.setString(4, LocalDateTime.now().toString());
            ps.setLong(5, wishlistId);

            if (ps.executeUpdate() == 0) {
                throw new DataAccessException("수정할 위시리스트 항목을 찾지 못했습니다.");
            }
        } catch (SQLException e) {
            throw new DataAccessException("위시리스트 항목을 수정하지 못했습니다.", e);
        }
    }

    public static void setCompleted(long wishlistId, boolean completed) {
        String sql = """
                UPDATE wishlist_item
                SET completed = ?, updated_at = ?
                WHERE wishlist_id = ?
                """;

        try (PreparedStatement ps = Database.connection().prepareStatement(sql)) {
            ps.setInt(1, completed ? 1 : 0);
            ps.setString(2, LocalDateTime.now().toString());
            ps.setLong(3, wishlistId);

            if (ps.executeUpdate() == 0) {
                throw new DataAccessException("상태를 변경할 위시리스트 항목을 찾지 못했습니다.");
            }
        } catch (SQLException e) {
            throw new DataAccessException("위시리스트 상태를 변경하지 못했습니다.", e);
        }
    }

    public static void delete(long wishlistId) {
        String sql = "DELETE FROM wishlist_item WHERE wishlist_id = ?";

        try (PreparedStatement ps = Database.connection().prepareStatement(sql)) {
            ps.setLong(1, wishlistId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("위시리스트 항목을 삭제하지 못했습니다.", e);
        }
    }

    private static WishlistItem mapRow(ResultSet rs) throws SQLException {
        return new WishlistItem(
                rs.getLong("wishlist_id"),
                rs.getLong("trip_id"),
                rs.getString("place_name"),
                Category.valueOf(rs.getString("category")),
                rs.getString("note"),
                rs.getInt("completed") == 1);
    }
}